$("#typesel").on('change', function(){
    //user selected the type of paper to upload
    type = $(this).val();

    //Let's get the requirements for the selected level
    reqs = $(this).parent('form').find(".form-group[data-for*='ne']")
 })