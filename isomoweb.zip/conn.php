<?php
	$db = new mysqli('localhost', 'isomoinf_custom', 'Jh&(c=}fEcSK', 'isomoinf_custom');
	$db->set_charset("utf8");
?>