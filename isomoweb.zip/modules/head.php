<title><?php echo !empty($title)?"$title | ":""?>Isomo</title>
<link rel="shortcut icon" href="<?php echo get_file('isomo.jpg'); ?>">

<!--Google -Fonts-->
<link href='https://fonts.googleapis.com/css?family=Sintony:400,700&subset=latin-ext' rel='stylesheet' type='text/css'>

<!--Font-awsome-->
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">

<!-- Bootstrap -->
<link rel="stylesheet" href="<?php echo get_file('css/bootstrap.min.css'); ?>">

<!-- Custom style -->
<link rel="stylesheet" href="<?php echo get_file('css/style.css'); ?>">