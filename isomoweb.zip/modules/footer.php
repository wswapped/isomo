<div class="container-fluid ft-container">
	<footer>
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4"></div>
			<div class="col-md-4"></div>
		</div>
		<div class="row">
			<div class="col-xs-12">&copy;ISOMO TECHNOLOGY LTD. <?php echo date('Y'); ?></div>
		</div>			
	</footer>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

<script type="text/javascript" src="<?php echo get_file('js/jquery.slim.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo get_file('js/tether.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo get_file('js/bootstrap.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo get_file('js/js.js'); ?>"></script>